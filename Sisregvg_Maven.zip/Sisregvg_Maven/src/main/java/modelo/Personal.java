package modelo;

import lombok.Data;

@Data

public class Personal {


    private Integer idper;
    private String nombre;
    private String apellido;
    private String dni;
    private String celular;
    private String email;
    private String domper;
    private String sexo;
    private String cargo;
    private String estper;
}
